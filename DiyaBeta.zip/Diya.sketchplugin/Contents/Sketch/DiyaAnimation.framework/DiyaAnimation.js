/*
// To load this framework, add the following code in your manifest.json

"commands": [
:
:
{
    "script" : "DiyaAnimation.framework/DiyaAnimation.js",
    "handlers" : {
        "actions" : {
            "Startup" : "onStartup",
            "OpenDocument":"onOpenDocument",
            "SelectionChanged.finish" : "onSelectionChanged"
        }
    }
}
]
*/

var onStartup = function(context) {
  var DiyaAnimation_FrameworkPath = DiyaAnimation_FrameworkPath || COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
  var DiyaAnimation_Log = DiyaAnimation_Log || log;
  (function() {
    var mocha = Mocha.sharedRuntime();
    var frameworkName = "DiyaAnimation";
    var directory = DiyaAnimation_FrameworkPath;
    if (mocha.valueForKey(frameworkName)) {
      DiyaAnimation_Log("loadFramework: `" + frameworkName + "` already loaded.");
      return true;
    } else if ([mocha loadFrameworkWithName:frameworkName inDirectory:directory]) {
      DiyaAnimation_Log("loadFramework: `" + frameworkName + "` success!");
      mocha.setValue_forKey_(true, frameworkName);
      return true;
    } else {
      DiyaAnimation_Log("loadFramework: `" + frameworkName + "` failed!: " + directory + ". Please define DiyaAnimation_FrameworkPath if you're trying to @import in a custom plugin");
      return false;
    }
  })();
};

//Event Listeners
var onShutdown = function(context) {
    DiyaAnimation.onShutdown(context);
}

var onSelectionChanged = function(context) {
  DiyaAnimation.onSelectionChanged(context);
};

var onCreateSymbolFinish = function(context) {
    DiyaAnimation.onCreateSymbolFinish(context);
}

var onCreateGroupFinish = function(context) {
    DiyaAnimation.onCreateGroupFinish(context);
}

var onInsertSymbol = function(context) {
    DiyaAnimation.onInsertSymbol(context);
}

var onLayersMovedStart = function(context) {
    DiyaAnimation.onLayersMovedStart(context);
}

var onLayersMoved = function(context) {
    DiyaAnimation.onLayersMoved(context);
}

var onOpenDocument = function(context) {
    DiyaAnimation.onOpenDocument(context);
}

var onSavedDocument = function(context) {
    DiyaAnimation.onSavedDocument(context);
}

var onCloseDocument = function(context) {
    DiyaAnimation.onCloseDocument(context);
}

//Menu Handlers
var onActivateConnector = function(context) {
    DiyaAnimation.onActivateConnector(context);
}

var onToggleDiyaUIVisibility = function(context) {
    DiyaAnimation.onToggleDiyaUIVisibility(context);
}

var onRebuildAnimations = function(context) {
    DiyaAnimation.onRebuildAnimations(context);
}

var onRunPreview = function(context) {
    DiyaAnimation.onRunPreview(context);
}

var onExportPrototype = function(context) {
    DiyaAnimation.onExportPrototype(context);
}

var onCopyPrototypeJSON = function(context) {
    DiyaAnimation.onCopyPrototypeJSON(context);
}

var onRunTestCode = function(context) {
    DiyaAnimation.runTestCodeForContext(context);
}
